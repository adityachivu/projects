function [freq] = hist(X)

%
%

[m, n] = size(X);


X = X + 1;
X = X * 100;
freq = zeros(400,400);
for i = 1:m
	for j = 1:n
		freq(j, floor(X(i,j)))++;
	end
end

end
