function [] = plothist(freq, i)

%
%

plot(1:400, freq(i,:));