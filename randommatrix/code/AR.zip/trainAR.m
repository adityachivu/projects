%
%
%
%
%

load('dataAR.mat');
X = modreg_img_cls(:,1:650)';

load('weightsAR25.mat');
Theta = weight_mat;

fprintf('\nsize of Input Matrix:\n');
[m n] = size(X);

Y = zeros(m, 25);

for i = 1:m
	Y(i, y(i)) = 1;
end

%%%	Pre-calculated weights
J = costAR(Theta(:), Y, X)
costFunction = @(p) costAR(p, Y, X);
options = optimset('MaxIter', 50);
[Weight, cost] = fmincg(costFunction, Theta(:));


Theta = reshape(Weight, 19800, 25);
printf('\n\nCost after using pre-calculated weights:\n');
J = costAR(Theta(:), Y, X)


%%%	Randomly initialized weights
Theta = rand(19800, 25);
J = costAR(Theta(:), Y, X)
costFunction = @(p) costAR(p, Y, X);
options = optimset('MaxIter', 50);
[Weight, cost] = fmincg(costFunction, Theta(:));

Theta = reshape(Weight, 19800, 25);
printf('\n\nCost after using random weights:\n');
J = costAR(Theta(:), Y, X)