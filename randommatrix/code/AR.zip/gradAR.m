function dJ = gradAR(Theta, y, X)
%
%	Function to calculate the cost of
%	Weights for SLP in recognition.
%
Theta = reshape(Theta, 19800, 25);
dJ = 0;

[m n] = size(X);

D = y - (X * Theta);
dJ = (1/m) * (X' * D);

dJ = dJ(:);
end
